// export const PicBaseUrl = "https://res.cloudinary.com/di5etqzhu/image/upload/v1666081152/images/";
export const PicBaseUrl = "https://siamsuits.s3.ap-northeast-1.amazonaws.com/images/";
export const PicBaseUrl4 = "https://siamsuits.s3.ap-northeast-1.amazonaws.com/"
// export const PicBaseUrl3 = "http://localhost:4545/";
export const PicBaseUrl3 = "http://54.248.164.243/";