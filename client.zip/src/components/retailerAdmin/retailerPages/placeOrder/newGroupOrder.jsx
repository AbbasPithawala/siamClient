import React from 'react'

export default function NewGroupOrder() {
    return (
        <>new Order</>
    )
}