import React from 'react'

export default function placeOrder() {
  return (
    <div>placeOrder</div>
  )
}
