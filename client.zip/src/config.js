import axios from 'axios'

export const axiosInstance = axios.create({
    // baseURL : "http://localhost:4545/"
    baseURL : "http://54.248.164.243/"
})

export const axiosInstance2 = axios.create({
    // baseURL : "http://localhost:4545/"
    baseURL : "http://54.248.164.243/"
})